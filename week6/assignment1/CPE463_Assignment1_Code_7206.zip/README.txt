1.open the homework folder
2.RUN 'pip install pipenv' in terminal
3.RUN 'pipenv shell' in terminal
4.Run 'pip install -r requirements.txt' before run the program in terminal
5.Run 'python3 assignment1_8.py' in terminal for number 8
5.Run 'python3 assignment1_9.py' in terminal for number 9
5.Run 'python3 assignment1_10.py' in terminal for number 10