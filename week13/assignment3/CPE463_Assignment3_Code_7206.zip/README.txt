1.open the homework folder
2.RUN 'pip install pipenv' in terminal
3.RUN 'pipenv shell' in terminal
4.Run 'pip install -r requirements.txt' before run the program in terminal
5.Run 'python3 assignment3_3.py' in terminal